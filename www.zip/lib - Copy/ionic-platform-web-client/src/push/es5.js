import { Push } from "./push";
import { PushToken } from "./push-token";

// Declare the window object
window.Ionic = window.Ionic || {};

// Ionic Namespace
Ionic.Push = Push;
Ionic.PushToken = PushToken;
