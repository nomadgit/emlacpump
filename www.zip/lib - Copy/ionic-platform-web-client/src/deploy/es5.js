import { Deploy } from "./deploy";

// Declare the window object
window.Ionic = window.Ionic || {};

// Ionic Namespace
Ionic.Deploy = Deploy;
